COMP2406 Assingment 1

Xiaoying Liu 100968424
Xiaofeng Luo 101007579

Use instruction:
To run the web page, switch to directory AS1, type 'node server.js' in command line
Then use url http://127.0.0.1:3000 to browse the web
Type in the song names in the text field of web page (case sensitive) and click submit to see the song
If the song exists, you can drag the words around to change their location
Click submit change to save your modification
Creadit: Code resources from 2017fall term 2406 tutorial 2 and 3.