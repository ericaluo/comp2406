function getRecipes() {

    let RecipesName = document.getElementById('Recipes').value
    if(RecipesName === '') {
        return alert('Please enter a Food')
    }

    let RecipesDiv = document.getElementById('FoodRecipes')
    RecipesDiv.innerHTML = ''

    let xhr = new XMLHttpRequest()
    xhr.onreadystatechange = () => {
        if (xhr.readyState == 4 && xhr.status == 200) {
            let response = JSON.parse(xhr.responseText).recipes
 			response.forEach((element) => {
				RecipesDiv.innerHTML = RecipesDiv.innerHTML + 
				`<div>
					<a href="${element.f2f_url}"><img src=${element.image_url}></a>
					<h2>${element.title}</h2>
				</div>`
				
			})
        }
    }
	
    xhr.open('GET', `/search?q=${RecipesName}`, true)
    xhr.send()
}

//Attach Enter-key Handler
const ENTER=13
document.getElementById("Recipes")
    .addEventListener("keyup", function(event) {
    event.preventDefault();
    if (event.keyCode === ENTER) {
        document.getElementById("submit").click();
    }
});