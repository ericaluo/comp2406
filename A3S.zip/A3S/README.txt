COMP2406 Assingment 3

Xiaofeng Luo 101007579

To install npm modules execute:
>npm install

This will install the modules listed as dependencies in the package.json file.

To run either execute
>npm start
or 
>node app.js

When you execute "express --version" you will see the version as 4.15.5
Finally open CMD and execute "node app.js" and open a browser to visit http://localhost:3000/ and click submit change to save your modification

Creadit: Code resources from 2017fall term 2406 tutorial 6 and 7 and course note 17.